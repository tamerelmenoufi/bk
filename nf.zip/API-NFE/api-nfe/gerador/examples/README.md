# Exemplos de Uso

[Para visualizar a documentação e os exemplos de uso veja a pasta docs](../docs/).

[Os arquivos de testes também podem ser usados como exemplo](../tests/).

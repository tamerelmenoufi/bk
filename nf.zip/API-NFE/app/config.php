<?php

// CONEXAO PDO MySQL
$PDO = new PDO("mysql:host=localhost;dbname=exemplo", "usuario", "senha");


// ENDEREÇO DA API
$endpoint = "https://localhost/SEUSISTEMA/api-nfe/"; // COM BARRA NO FINAL


ini_set('display_errors', 'Off');
